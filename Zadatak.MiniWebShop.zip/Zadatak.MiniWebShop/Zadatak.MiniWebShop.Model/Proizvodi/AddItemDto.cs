﻿namespace Zadatak.MiniWebShop.Model.Proizvodi
{
    public class AddItemDto
    {
        public int Id { get; set; }
    }
}